-- نفّذ هذا الملف في Supabase > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'sub_admin' check (role in ('admin','sub_admin')),
  permissions jsonb not null default '{"create_licenses":false}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  status text not null default 'active' check (status in ('active','disabled')),
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  max_devices integer not null default 1 check (max_devices between 1 and 20)
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  insert into public.profiles(id,email,role,permissions)
  values(new.id,new.email,'sub_admin','{"create_licenses":false}'::jsonb)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.licenses enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$
  select exists(select 1 from public.profiles where id=auth.uid() and role='admin');
$$;

drop policy if exists "read own profile or admin" on public.profiles;
create policy "read own profile or admin" on public.profiles
for select to authenticated using (id=auth.uid() or public.is_admin());

drop policy if exists "admin manage profiles" on public.profiles;
create policy "admin manage profiles" on public.profiles
for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "read own or admin licenses" on public.licenses;
create policy "read own or admin licenses" on public.licenses
for select to authenticated using (created_by=auth.uid() or public.is_admin());

-- لا تسمح الواجهة بإدخال الأكواد مباشرة؛ Edge Function تستخدم service role بعد فحص الصلاحية.
revoke insert, update, delete on public.licenses from anon, authenticated;
revoke insert, delete on public.profiles from anon, authenticated;
grant select on public.profiles, public.licenses to authenticated;

-- بعد إنشاء حسابك من صفحة الموقع، استبدل البريد في السطر التالي ونفذه مرة واحدة:
-- update public.profiles set role='admin', permissions='{"create_licenses":true}'::jsonb
-- where email='YOUR_ADMIN_EMAIL';
