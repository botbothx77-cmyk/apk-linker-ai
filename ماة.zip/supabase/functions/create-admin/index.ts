import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async(req)=>{
  if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
  const json=(body:any,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
  try{
    const url=Deno.env.get("SUPABASE_URL")!, anon=Deno.env.get("SUPABASE_ANON_KEY")!, service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const auth=req.headers.get("Authorization"); if(!auth) return json({error:true,message:"Unauthorized"},401);
    const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}}});
    const {data:{user},error:ue}=await userClient.auth.getUser(); if(ue||!user) return json({error:true,message:"Unauthorized"},401);
    const admin=createClient(url,service);
    const {data:profile}=await admin.from("profiles").select("role").eq("id",user.id).single();
    if(profile?.role!=="admin") return json({error:true,message:"Admin only"},403);
    const body=await req.json(); const email=String(body.email||"").trim().toLowerCase(); const password=String(body.password||"");
    if(!email||password.length<8) return json({error:true,message:"Email and password (8+ chars) required"},400);
    const {data,error}=await admin.auth.admin.createUser({email,password,email_confirm:true});
    if(error) return json({error:true,message:error.message},400);
    const permissions={create_licenses:body.permissions?.create_licenses===true};
    const {error:pe}=await admin.from("profiles").update({role:"sub_admin",permissions}).eq("id",data.user.id);
    if(pe){await admin.auth.admin.deleteUser(data.user.id);return json({error:true,message:pe.message},500);}
    return json({message:"تم إنشاء حساب المسؤول بنجاح."});
  }catch(e){return json({error:true,message:String(e)},500);}
});