import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type","Access-Control-Allow-Methods":"POST, OPTIONS"};
Deno.serve(async(req)=>{
  if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
  const json=(body:any,status=200)=>new Response(JSON.stringify(body),{status,headers:{...cors,"Content-Type":"application/json"}});
  try{
    const url=Deno.env.get("SUPABASE_URL")!, anon=Deno.env.get("SUPABASE_ANON_KEY")!, service=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const auth=req.headers.get("Authorization"); if(!auth) return json({message:"Unauthorized"},401);
    const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}}});
    const {data:{user},error:ue}=await userClient.auth.getUser(); if(ue||!user) return json({message:"Unauthorized"},401);
    const admin=createClient(url,service);
    const {data:profile}=await admin.from("profiles").select("role,permissions").eq("id",user.id).single();
    if(!profile || (profile.role!=="admin" && profile.permissions?.create_licenses!==true)) return json({message:"Not allowed"},403);
    const body=await req.json();
    if(body.action!=="create") return json({message:"Unsupported action"},400);
    const days=Number(body.duration_days),devices=Number(body.max_devices);
    if(!Number.isInteger(days)||days<1||days>3650||!Number.isInteger(devices)||devices<1||devices>20) return json({message:"Invalid duration or device limit"},400);
    const code="LIC-"+crypto.randomUUID().replaceAll("-","").slice(0,16).toUpperCase();
    const expires=new Date(Date.now()+days*86400000).toISOString();
    const {error}=await admin.from("licenses").insert({code,created_by:user.id,expires_at:expires,max_devices:devices});
    if(error) return json({message:error.message},500);
    return json({code,expires_at:expires,max_devices:devices});
  }catch(e){return json({message:String(e)},500);}
});